@include('template_cat._layouts.block._block_item',['block_detail'=>$block_detail])
