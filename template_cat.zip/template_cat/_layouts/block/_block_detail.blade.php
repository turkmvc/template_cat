@include('template_example._layouts.block._block_item',['block_detail'=>$block_detail])
